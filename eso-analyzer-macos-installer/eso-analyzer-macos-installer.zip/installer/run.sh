#!/bin/bash
echo "ESO Live Encounter Log Sets & Abilities Analyzer"
echo "================================================="
echo ""
echo "Starting analyzer in test mode..."
echo "Press Ctrl+C to stop"
echo ""
./eso-analyzer --test-mode
